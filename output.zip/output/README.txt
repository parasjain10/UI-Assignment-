Maintain Role Level Access Control (React + Vite)

What this is
- Frontend assignment screen built in React.
- Includes two states:
  1) Initial/empty state with illustration
  2) Table state after clicking Search
- Styling is plain CSS (no component library).

Tech
- React 18
- Vite
- CSS (Flex/Grid)

How to run from zip
1. Extract output.zip.
2. Open terminal in the extracted output folder.
3. Install packages:
   npm install
4. Start local server:
   npm run dev
5. Open in browser:
   http://localhost:5173

If npm is not found, install Node.js 18+ first:
https://nodejs.org

Useful commands
- npm run dev      -> start dev server
- npm run build    -> create production build in dist
- npm run preview  -> preview production build

Main files
- src/App.jsx
- src/components/TopNav.jsx
- src/components/Sidebar.jsx
- src/components/SearchCriteria.jsx
- src/components/AccessControlsTable.jsx
- src/components/EmptyState.jsx
- style.css

Behavior notes
- Search button switches to table view.
- Clear button switches back to empty view.
- Tags in the multi-select fields can be removed individually.

Submission note
Before submitting zip, remove folders that are re-creatable locally:
- node_modules
- dist (optional to keep out)

PowerShell zip command from parent folder:
Compress-Archive -Path .\output -DestinationPath .\output.zip -Force
