import { useState } from "react";
import TopNav from "./components/TopNav";
import Sidebar from "./components/Sidebar";
import SearchCriteria from "./components/SearchCriteria";
import AccessControlsTable from "./components/AccessControlsTable";
import EmptyState from "./components/EmptyState";

// small breadcrumb — kept separate so it's easier to update paths later
function Breadcrumb() {
  return (
    <nav className="breadcrumb">
      <a href="#">Home</a>
      <span className="bc-sep">›</span>
      <a href="#">Admin</a>
      <span className="bc-sep">›</span>
      <span className="bc-active">Access Control</span>
    </nav>
  );
}

function App() {
  const [showResults, setShowResults] = useState(false);

  function handleSearch() {
    setShowResults(true);
  }

  function handleClear() {
    setShowResults(false);
  }

  return (
    <div className="app-shell">
      <TopNav />
      <div className="app-body">
        <Sidebar />
        <main className="main-area">
          <Breadcrumb />
          <div className="page-card">
            <h1 className="page-title">Maintain Role Level Access Control</h1>
            <hr className="page-divider" />
            <SearchCriteria onSearch={handleSearch} onClear={handleClear} />
            {showResults ? <AccessControlsTable /> : <EmptyState />}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
