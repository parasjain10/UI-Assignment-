// mock data from the design screenshot
const rows = [
  {
    cat: "NRI",
    sub: "Address Update",
    field: "Address",
    access: "No Access",
    mask: "XXXX XXXX XXXX...XXXX",
  },
  {
    cat: "NRI",
    sub: "Address Update",
    field: "Aadhaar Number",
    access: "No Access",
    mask: "XXXX XXXX XXXX",
  },
  {
    cat: "NRI",
    sub: "Address Update",
    field: "Account Number",
    access: "No Access",
    mask: "XXXX XXXX XXXX XXXX",
  },
  {
    cat: "NRI",
    sub: "Address Update",
    field: "Related Party",
    access: "No Access",
    mask: "XXXXXXXXXX",
  },
  {
    cat: "Corporate",
    sub: "Stop Check",
    field: "Name",
    access: "No Access",
    mask: "XXXX XXXXX XXXXX",
  },
  {
    cat: "Corporate",
    sub: "Stop Check",
    field: "DOB",
    access: "No Access",
    mask: "XX-XX-XXXX",
  },
  {
    cat: "Corporate",
    sub: "Stop Check",
    field: "Aadhar Number",
    access: "No Access",
    mask: "XXXX XXXX XXXX",
  },
  {
    cat: "Corporate",
    sub: "Stop Check",
    field: "Phone Number",
    access: "No Access",
    mask: "XX XXXXX XXXXX",
  },
];

function AccessControlsTable() {
  return (
    <div className="table-section">
      <div className="table-header-row">
        <h2 className="table-title">Access Controls</h2>
        <button className="filter-btn">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path
              d="M2 4h12M4 8h8M6 12h4"
              stroke="#2563EB"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </svg>
        </button>
      </div>
      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Case Category</th>
              <th>Case Sub-category</th>
              <th>Field Name</th>
              <th>Access Type</th>
              <th>Masking Preview</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, idx) => (
              <tr key={idx}>
                <td>{row.cat}</td>
                <td>{row.sub}</td>
                <td>{row.field}</td>
                <td>{row.access}</td>
                <td className="mask-col">{row.mask}</td>
                <td>
                  <div className="action-icons">
                    {/* view */}
                    <button className="action-btn">
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                      >
                        <path
                          d="M1 8s2.5-5 7-5 7 5 7 5-2.5 5-7 5-7-5-7-5z"
                          stroke="#2563EB"
                          strokeWidth="1.4"
                        />
                        <circle
                          cx="8"
                          cy="8"
                          r="2"
                          stroke="#2563EB"
                          strokeWidth="1.4"
                        />
                      </svg>
                    </button>
                    {/* edit */}
                    <button className="action-btn">
                      <svg
                        width="16"
                        height="16"
                        viewBox="0 0 16 16"
                        fill="none"
                      >
                        <path
                          d="M11 2l3 3-8 8H3v-3l8-8z"
                          stroke="#2563EB"
                          strokeWidth="1.4"
                          strokeLinejoin="round"
                        />
                        <path d="M9 4l3 3" stroke="#2563EB" strokeWidth="1.4" />
                      </svg>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AccessControlsTable;
