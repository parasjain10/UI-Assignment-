// shown before search is triggered
function EmptyState() {
  return (
    <div className="empty-state">
      <svg width="220" height="180" viewBox="0 0 220 180" fill="none">
        {/* left bg card */}
        <rect
          x="20"
          y="40"
          width="72"
          height="90"
          rx="6"
          fill="#E9EEF6"
          stroke="#C7D3E8"
          strokeWidth="1.2"
        />
        <circle cx="56" cy="68" r="14" fill="#C7D3E8" />
        <path d="M44 68a12 12 0 0 1 24 0" fill="#B0BDD4" />
        <rect x="36" y="88" width="40" height="5" rx="2.5" fill="#C7D3E8" />
        <rect x="36" y="97" width="30" height="4" rx="2" fill="#D8E2F0" />
        <rect x="36" y="105" width="34" height="4" rx="2" fill="#D8E2F0" />
        <rect x="36" y="113" width="24" height="4" rx="2" fill="#D8E2F0" />

        {/* right bg card */}
        <rect
          x="128"
          y="40"
          width="72"
          height="90"
          rx="6"
          fill="#E9EEF6"
          stroke="#C7D3E8"
          strokeWidth="1.2"
        />
        <circle cx="164" cy="68" r="14" fill="#C7D3E8" />
        <path d="M152 68a12 12 0 0 1 24 0" fill="#B0BDD4" />
        <rect x="144" y="88" width="40" height="5" rx="2.5" fill="#C7D3E8" />
        <rect x="144" y="97" width="30" height="4" rx="2" fill="#D8E2F0" />
        <rect x="144" y="105" width="34" height="4" rx="2" fill="#D8E2F0" />
        <rect x="144" y="113" width="24" height="4" rx="2" fill="#D8E2F0" />

        {/* center card (slightly taller) */}
        <rect
          x="74"
          y="28"
          width="72"
          height="90"
          rx="6"
          fill="#F0F4FC"
          stroke="#B8C9E8"
          strokeWidth="1.5"
        />
        <circle cx="110" cy="56" r="15" fill="#D0DCEF" />
        <path d="M97 56a13 13 0 0 1 26 0" fill="#B8C9E8" />
        <rect x="90" y="78" width="40" height="5" rx="2.5" fill="#C3D0E8" />
        <rect x="90" y="87" width="30" height="4" rx="2" fill="#D5E0F0" />
        <rect x="90" y="95" width="34" height="4" rx="2" fill="#D5E0F0" />
        <rect x="90" y="103" width="24" height="4" rx="2" fill="#D5E0F0" />

        {/* magnifier glass */}
        <circle
          cx="122"
          cy="100"
          r="28"
          fill="#EAF0FB"
          stroke="#2563EB"
          strokeWidth="3"
        />
        <circle cx="122" cy="100" r="20" fill="#D6E4F7" />
        <circle
          cx="120"
          cy="96"
          r="7"
          fill="#C3D5EF"
          stroke="#2563EB"
          strokeWidth="2"
        />
        <path d="M116 96a4 4 0 0 1 8 0" fill="#9DB8E0" />
        <rect x="119" y="101" width="2" height="6" rx="1" fill="#9DB8E0" />
        <line
          x1="138"
          y1="116"
          x2="150"
          y2="132"
          stroke="#2563EB"
          strokeWidth="5"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
}

export default EmptyState;
