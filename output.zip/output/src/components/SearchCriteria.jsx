import { useState } from "react";

// renders a single removable chip/tag
function Tag({ label, onRemove }) {
  return (
    <span className="tag">
      {label}
      <button
        type="button"
        className="tag-remove"
        onClick={() => onRemove(label)}
      >
        ×
      </button>
    </span>
  );
}

// multi-select display — just shows tags + arrow, no actual dropdown needed for this screen
function TagSelect({ tags, onRemove }) {
  return (
    <div className="multi-select">
      {tags.map((t) => (
        <Tag key={t} label={t} onRemove={onRemove} />
      ))}
      <span className="ms-arrow">
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
          <path
            d="M2 4l4 4 4-4"
            stroke="#6B7280"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>
    </div>
  );
}

function SearchCriteria({ onSearch, onClear }) {
  const [categories, setCategories] = useState(["NRI", "Corporate"]);
  const [subCategories, setSubCategories] = useState([
    "Address Update",
    "Stop Check",
  ]);

  function removeCategory(val) {
    setCategories(categories.filter((c) => c !== val));
  }

  function removeSubCategory(val) {
    setSubCategories(subCategories.filter((s) => s !== val));
  }

  function handleClear() {
    setCategories([]);
    setSubCategories([]);
    onClear();
  }

  return (
    <div className="search-criteria-panel">
      <p className="panel-label">Search Criteria</p>
      <div className="criteria-row">
        <div className="field-group">
          <label className="field-label" htmlFor="role">
            Role <span className="required">*</span>
          </label>
          <div className="text-input-wrap">
            <input
              id="role"
              type="text"
              className="text-input"
              defaultValue="Branch Manager"
            />
            <span className="input-icon">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <circle
                  cx="7"
                  cy="7"
                  r="4"
                  stroke="#9CA3AF"
                  strokeWidth="1.5"
                />
                <path
                  d="M10.5 10.5l2.5 2.5"
                  stroke="#9CA3AF"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
              </svg>
            </span>
          </div>
        </div>
        <div className="field-group">
          <label className="field-label" htmlFor="access-type">
            Access Control Type <span className="required">*</span>
          </label>
          <select
            id="access-type"
            className="select-input"
            defaultValue="Field Level"
          >
            <option>Field Level</option>
            <option>Screen Level</option>
            <option>API Level</option>
          </select>
        </div>
        <div className="field-group">
          <label className="field-label">Case Category</label>
          <TagSelect tags={categories} onRemove={removeCategory} />
        </div>
      </div>
      <div className="criteria-row second-row">
        <div className="field-group">
          <label className="field-label">Case Sub-category</label>
          <TagSelect tags={subCategories} onRemove={removeSubCategory} />
        </div>
      </div>
      <div className="criteria-actions">
        <button type="button" className="btn-clear" onClick={handleClear}>
          Clear
        </button>
        <button type="button" className="btn-search" onClick={onSearch}>
          Search
        </button>
      </div>
    </div>
  );
}

export default SearchCriteria;
