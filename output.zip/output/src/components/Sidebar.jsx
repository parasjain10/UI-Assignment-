// left sidebar with icon nav
function Sidebar() {
  return (
    <aside className="sidebar">
      {/* collapse toggle */}
      <button className="sidebar-icon collapse-btn">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <path
            d="M5 2l5 5-5 5"
            stroke="#fff"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>

      <div className="sidebar-nav">
        <button className="sidebar-icon">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <rect
              x="2"
              y="2"
              width="6"
              height="6"
              rx="1"
              stroke="#fff"
              strokeWidth="1.5"
            />
            <rect
              x="10"
              y="2"
              width="6"
              height="6"
              rx="1"
              stroke="#fff"
              strokeWidth="1.5"
            />
            <rect
              x="2"
              y="10"
              width="6"
              height="6"
              rx="1"
              stroke="#fff"
              strokeWidth="1.5"
            />
            <rect
              x="10"
              y="10"
              width="6"
              height="6"
              rx="1"
              stroke="#fff"
              strokeWidth="1.5"
            />
          </svg>
        </button>
        <button className="sidebar-icon">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <rect
              x="2"
              y="2"
              width="14"
              height="14"
              rx="2"
              stroke="#fff"
              strokeWidth="1.5"
            />
            <path
              d="M5 12l2.5-3 2.5 2 3-4"
              stroke="#fff"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </button>
        <button className="sidebar-icon">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <circle cx="9" cy="9" r="7" stroke="#fff" strokeWidth="1.5" />
            <path
              d="M9 6v6M6 9h6"
              stroke="#fff"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </svg>
        </button>
        {/* active page - access control */}
        <button className="sidebar-icon active-icon">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <circle cx="7" cy="6" r="2.5" stroke="#fff" strokeWidth="1.5" />
            <path
              d="M2 15c0-2.761 2.239-4 5-4s5 1.239 5 4"
              stroke="#fff"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
            <path
              d="M13 8v4M15 10h-4"
              stroke="#fff"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </svg>
        </button>
        <button className="sidebar-icon">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <circle cx="8" cy="8" r="4.5" stroke="#fff" strokeWidth="1.5" />
            <path
              d="M13 13l3 3"
              stroke="#fff"
              strokeWidth="1.5"
              strokeLinecap="round"
            />
            <circle cx="8" cy="7" r="1.5" stroke="#fff" strokeWidth="1.2" />
            <path
              d="M5 11c0-1.657 1.343-2.5 3-2.5"
              stroke="#fff"
              strokeWidth="1.2"
              strokeLinecap="round"
            />
          </svg>
        </button>
      </div>
    </aside>
  );
}

export default Sidebar;
