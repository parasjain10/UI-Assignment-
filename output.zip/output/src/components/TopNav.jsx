// top navigation bar
function TopNav() {
  return (
    <header className="topnav">
      <span className="topnav-logo">Logo</span>

      <div className="topnav-search">
        <div className="search-group">
          <div className="search-category">
            <span>Category</span>
            {/* dropdown arrow */}
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path
                d="M2 4l4 4 4-4"
                stroke="#6B7280"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <input className="search-input" type="text" placeholder="Search" />
          <button className="search-btn" type="button">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <circle
                cx="7"
                cy="7"
                r="4.5"
                stroke="#6B7280"
                strokeWidth="1.5"
              />
              <path
                d="M10.5 10.5l2.5 2.5"
                stroke="#6B7280"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
          </button>
        </div>
      </div>

      <div className="nav-right-icons">
        {/* bell icon */}
        <button className="icon-btn">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path
              d="M9 2a5 5 0 0 0-5 5v3l-1.5 2h13L14 10V7a5 5 0 0 0-5-5z"
              stroke="#374151"
              strokeWidth="1.4"
            />
            <path
              d="M7.5 14.5a1.5 1.5 0 0 0 3 0"
              stroke="#374151"
              strokeWidth="1.4"
              strokeLinecap="round"
            />
          </svg>
        </button>
        {/* user avatar */}
        <button className="icon-btn avatar-btn">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <circle cx="9" cy="7" r="3" stroke="#374151" strokeWidth="1.4" />
            <path
              d="M3 15c0-3.314 2.686-5 6-5s6 1.686 6 5"
              stroke="#374151"
              strokeWidth="1.4"
              strokeLinecap="round"
            />
          </svg>
        </button>
      </div>
    </header>
  );
}

export default TopNav;
